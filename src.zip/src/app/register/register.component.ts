import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserserviceService } from '../service/userservice.service';
import { HomeComponent } from '../home/home.component';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
    registerForm! : FormGroup;
    submitted :boolean= false;

    authors:any;
    constructor(private authorData : UserserviceService,private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            title: ['', Validators.required],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(6)]],
            confirmPassword: ['', Validators.required],
            acceptTerms: [false, Validators.requiredTrue]
        },
        )};

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    this.authorData.fetchApi().subscribe((data)=>{
      this.authors=data;
    
  }
    
      PostData(data:any){
      console.log(this.Register.value)
      this.authorData.PostauthorData(data).subscribe((result)=>{
        console.log(result);
      });

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        // display form values on success
        alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
    }
  }

    //this.router.navigate(['./home']);
    
  
  


















// export class RegisterComponent {
//   Register = new FormGroup({
//     name:new FormControl(""),
//     age:new FormControl(""),
//     role:new FormControl(""),
//     profession:new FormControl(""),
//     email:new FormControl("")
//   });

  
// authors:any;
// constructor ( private authorData : UserserviceService){
//     this.authorData.fetchApi().subscribe((data)=>{
//     this.authors=data;
//   })
// }
  
//     PostData(data:any){
//     console.log(this.Register.value)
//     this.authorData.PostauthorData(data).subscribe((result)=>{
//       console.log(result);
//     });
//     //this.router.navigate(['./home']);
    
//   }
  
// }
