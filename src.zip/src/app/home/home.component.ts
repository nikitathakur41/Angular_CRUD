import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserserviceService } from '../service/userservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  authors:any;
constructor(private router:Router,private authorData : UserserviceService){
  this.authorData.fetchApi().subscribe((data)=>{
    this.authors = data;
  });

}
  show: boolean = true;
  button: any = 'show';

  onClick() {
    this.show = !this.show
    if (this.show)
      this.button = "Hide";
    else
      this.button = "Show";
  }

 

  arr = [{
    id: 1,
    fName: "Nikita",
    lName: "Thakur",
    userName: "nikitathakur",
    email: "nikitathakur0904@gmail.com"
  },
  {
    id: 2,
    fName: "Anshu",
    lName: "Thakur",
    userName: "anshuthakur",
    email: "anshuthakur0904@gmail.com"
  },
  {
    id: 3,
    fName: "Ishani",
    lName: "Thakur",
    userName: "ishanithakur",
    email: "ishanithakur0904@gmail.com"
  }]


  ngOnInit(): void {
    console.log("Hello World")
  }

}
